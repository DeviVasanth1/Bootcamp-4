# 🚨 Real-Time Fraud Detection Pipeline using Google Cloud

This project is a real-time fraud detection system that processes streaming transaction data using Google Cloud Platform (GCP) tools. It flags suspicious transactions and stores them in BigQuery for further analysis.

## ✅ Completed Components

### 1. Google Cloud Setup
- Created GCP Project: `devi-bootcamp`
- Enabled necessary APIs: Pub/Sub, Dataflow, BigQuery, Cloud Storage

### 2. Pub/Sub
- Created Topic: `fraud-transactions-topic`
- Created a `publisher.py` to simulate and publish 10 fake transactions

### 3. Dataflow (Apache Beam)
- Developed and ran a `pipeline.py`:
  - Reads messages from the Pub/Sub topic
  - Flags high-risk transactions (based on IP and amount thresholds)
  - Writes flagged transactions to BigQuery table `fraud_detection.flagged_transactions`
- Used `DataflowRunner` to deploy and monitor the pipeline

### 4. BigQuery
- Created dataset: `fraud_detection`
- Created table: `flagged_transactions`
- Verified data ingestion by running SQL queries via `bq` command-line

### 5. Export to Cloud Storage
- Exported flagged transactions to CSV format using `bq extract`
- Destination: `gs://devi-bootcamp-exports/flagged_transactions.csv`

## 📊 Example BigQuery Query
```
bq query --use_legacy_sql=false '
SELECT transaction_id, user_id, amount, country, ip, timestamp
FROM `devi-bootcamp.fraud_detection.flagged_transactions`
ORDER BY timestamp DESC
LIMIT 10'
```

## 📁 Folder Structure
```
.
├── publisher.py
├── pipeline.py
├── README.md
```

## 🛠 Next Steps
- Build a real-time dashboard using Looker Studio or Grafana
- Add anomaly detection models for more complex fraud patterns
- Set up alerting for flagged transactions

## 📎 References
- [Apache Beam Python SDK](https://beam.apache.org/documentation/sdks/python/)
- [Google Cloud Dataflow](https://cloud.google.com/dataflow/docs)
- [BigQuery Export](https://cloud.google.com/bigquery/docs/exporting-data)